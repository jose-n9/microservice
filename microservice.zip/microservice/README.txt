
Micro-Serivce Instrucitons:

    First, I would implement the SQL for the login page.
    Second, I would review and fix any issues on the HTML page, including the project description.
    Third, I would update the database and password in the microservice.js file and fix all the places where the table would be accessed.
    Fourth, I would install the required packages: body-parser, express, and mysql2.
        npm install body-parser express mysql2 
    Fifth, I would go to the login.js file and update the filenames to open upon clicking the LOGIN and REGISTER buttons.